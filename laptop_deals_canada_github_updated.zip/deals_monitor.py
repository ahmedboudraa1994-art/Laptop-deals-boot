import os
import re
import html
import time
import json
import requests
from datetime import datetime
from bs4 import BeautifulSoup

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()

BUDGET_4050 = float(os.getenv("BUDGET_4050", "1000"))
BUDGET_4060 = float(os.getenv("BUDGET_4060", "1150"))
SEND_ALWAYS = os.getenv("SEND_ALWAYS", "true").lower() == "true"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/122 Safari/537.36",
    "Accept-Language": "en-CA,en;q=0.9,fr-CA;q=0.8,fr;q=0.7",
}

SEARCH_PAGES = [
    {
        "store": "Best Buy Canada",
        "url": "https://www.bestbuy.ca/en-ca/search?search=rtx%204050%20laptop",
        "priority": 10,
    },
    {
        "store": "Best Buy Open Box",
        "url": "https://www.bestbuy.ca/en-ca/search?search=open%20box%20rtx%204050%20laptop",
        "priority": 10,
    },
    {
        "store": "Staples Canada",
        "url": "https://www.staples.ca/search?query=rtx%204050%20laptop",
        "priority": 8,
    },
    {
        "store": "Canada Computers",
        "url": "https://www.canadacomputers.com/search/results_details.php?language=en&keywords=rtx+4050+laptop",
        "priority": 8,
    },
    {
        "store": "Memory Express",
        "url": "https://www.memoryexpress.com/Search/Products?Search=rtx%204050%20laptop",
        "priority": 7,
    },
    {
        "store": "Walmart Canada",
        "url": "https://www.walmart.ca/search?q=rtx%204050%20laptop",
        "priority": 6,
    },
    {
        "store": "Amazon Canada",
        "url": "https://www.amazon.ca/s?k=rtx+4050+laptop",
        "priority": 6,
    },
    {
        "store": "Newegg Canada",
        "url": "https://www.newegg.ca/p/pl?d=rtx+4050+laptop",
        "priority": 6,
    },
    {
        "store": "Lenovo Canada",
        "url": "https://www.lenovo.com/ca/en/search?fq=&text=loq%20rtx%204050",
        "priority": 8,
    },
    {
        "store": "HP Canada",
        "url": "https://www.hp.com/ca-en/shop/sitesearch?keyword=victus%20rtx%204050",
        "priority": 7,
    },
    {
        "store": "Acer Canada",
        "url": "https://store.acer.com/en-ca/catalogsearch/result/?q=rtx%204050%20laptop",
        "priority": 7,
    },
    {
        "store": "ASUS Canada",
        "url": "https://shop.asus.com/ca-en/catalogsearch/result/?q=rtx%204050",
        "priority": 7,
    },
    {
        "store": "Dell Canada",
        "url": "https://www.dell.com/en-ca/search/rtx%204050%20laptop",
        "priority": 7,
    },
]

GOOD_MODELS = [
    "loq", "legion", "tuf", "nitro", "victus", "omen", "katana", "g15",
    "alienware", "predator", "rog", "zephyrus"
]

BAD_SIGNALS = [
    "rtx 2050", "rtx 3050", "8gb ram", "8 gb ram"
]

def money_to_float(s: str):
    s = s.replace(",", "").replace("CAD", "").replace("$", "").strip()
    try:
        return float(s)
    except Exception:
        return None

def extract_prices(text: str):
    # Finds Canadian-style dollar prices like $999.99 or CAD 1,099.99
    matches = re.findall(r"(?:CAD\s*)?\$\s?([0-9]{3,4}(?:,[0-9]{3})?(?:\.[0-9]{2})?)", text, flags=re.I)
    return [money_to_float(m) for m in matches if money_to_float(m) is not None]

def score_candidate(text: str, prices, priority: int):
    t = text.lower()
    if not any(gpu in t for gpu in ["rtx 4050", "rtx 4060", "rtx 4070"]):
        return None

    if any(bad in t for bad in BAD_SIGNALS) and "rtx 4050" not in t and "rtx 4060" not in t:
        return None

    min_price = min(prices) if prices else None
    if min_price is None:
        return None

    gpu = "RTX 4070" if "rtx 4070" in t else "RTX 4060" if "rtx 4060" in t else "RTX 4050"
    budget = 1300 if gpu == "RTX 4070" else BUDGET_4060 if gpu == "RTX 4060" else BUDGET_4050

    model_bonus = 0
    for m in GOOD_MODELS:
        if m in t:
            model_bonus += 8

    price_bonus = max(0, budget - min_price) / 20
    gpu_bonus = {"RTX 4050": 10, "RTX 4060": 22, "RTX 4070": 35}[gpu]
    open_box_bonus = 6 if any(x in t for x in ["open box", "geek squad", "refurb", "renewed", "recertified"]) else 0

    score = priority + model_bonus + price_bonus + gpu_bonus + open_box_bonus

    if min_price <= budget:
        decision = "ACHÈTE / très intéressant"
    elif min_price <= budget + 100:
        decision = "À surveiller"
    else:
        decision = "Trop cher"

    return {
        "gpu": gpu,
        "price": min_price,
        "score": round(score, 1),
        "decision": decision,
    }

def clean_snippet(text: str, max_len=230):
    text = re.sub(r"\s+", " ", text)
    text = html.unescape(text).strip()
    return text[:max_len] + ("..." if len(text) > max_len else "")

def fetch_page(item):
    try:
        r = requests.get(item["url"], headers=HEADERS, timeout=20)
        return r.status_code, r.text
    except Exception as e:
        return None, str(e)

def scan():
    results = []
    errors = []

    for item in SEARCH_PAGES:
        time.sleep(1.2)
        status, body = fetch_page(item)
        if status != 200:
            errors.append(f'{item["store"]}: erreur {status}')
            continue

        soup = BeautifulSoup(body, "html.parser")
        text = soup.get_text(" ", strip=True)
        text_low = text.lower()

        # If the page clearly has no GPU terms, skip.
        if not any(x in text_low for x in ["rtx 4050", "rtx 4060", "rtx 4070"]):
            continue

        prices = extract_prices(text)
        candidate = score_candidate(text, prices, item["priority"])

        if candidate:
            results.append({
                "store": item["store"],
                "url": item["url"],
                "snippet": clean_snippet(text),
                **candidate
            })

    results.sort(key=lambda x: (x["decision"] != "ACHÈTE / très intéressant", -x["score"], x["price"]))
    return results[:8], errors

def send_telegram(message: str):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("Telegram secrets missing. Message would be:")
        print(message)
        return

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "disable_web_page_preview": False,
        "parse_mode": "HTML",
    }
    r = requests.post(url, json=payload, timeout=20)
    print(r.status_code, r.text[:300])
    r.raise_for_status()

def build_message(results, errors):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [f"🔎 <b>Update deals laptops Canada</b> — {now}", ""]

    if not results:
        lines += [
            "Aujourd’hui je n’ai pas trouvé de deal exceptionnel RTX 4050/4060 dans tes critères.",
            "",
            "Décision: 🟡 attends encore.",
        ]
    else:
        lines.append("Meilleures pistes trouvées:")
        for i, r in enumerate(results, 1):
            lines += [
                "",
                f"{i}. <b>{r['store']}</b>",
                f"GPU détecté: <b>{r['gpu']}</b>",
                f"Prix détecté: <b>${r['price']:.2f} CAD</b>",
                f"Décision: <b>{r['decision']}</b>",
                f"Lien: {r['url']}",
            ]

    if errors:
        lines += ["", "⚠️ Pages non lues correctement: " + "; ".join(errors[:5])]

    lines += ["", "Critères: RTX 4050 ≤ $1000, RTX 4060 ≤ $1150, Canada, neuf/open box/refurb."]
    return "\n".join(lines)

if __name__ == "__main__":
    results, errors = scan()
    message = build_message(results, errors)

    if SEND_ALWAYS or results:
        send_telegram(message)
    else:
        print(message)
