# Laptop Deals Canada Monitor

Surveille les deals laptops Canada et envoie une notification Telegram.

## Ce que ça surveille
- Best Buy Canada + Open Box
- Staples
- Walmart Canada
- Amazon Canada
- Lenovo / HP / ASUS / Acer / Dell Canada
- Canada Computers
- Memory Express
- Newegg Canada

## Critères actuels
- RTX 4050 à 1000 $ CAD ou moins
- RTX 4060 à 1150 $ CAD ou moins
- Modèles ciblés: Lenovo LOQ/Legion, ASUS TUF, Acer Nitro, HP Victus/Omen, MSI Katana, Dell G15/Alienware
- Neuf + open box + refurbished

## Installation depuis iPhone

### 1) Créer le bot Telegram
1. Ouvre Telegram.
2. Cherche `@BotFather`.
3. Envoie `/newbot`.
4. Donne un nom, par exemple `Laptop Deals Canada`.
5. Donne un username qui finit par `bot`, par exemple `laptop_deals_hamdi_bot`.
6. Copie le token donné par BotFather.

### 2) Trouver ton chat ID
1. Dans Telegram, cherche `@userinfobot`.
2. Clique Start.
3. Copie ton `Id`.

### 3) Créer le repo GitHub
1. Va sur github.com depuis Safari.
2. Crée un compte si nécessaire.
3. Crée un nouveau repository privé, par exemple `laptop-deals-canada`.

### 4) Ajouter les fichiers
Ajoute ces fichiers au repo:
- `deals_monitor.py`
- `requirements.txt`
- `.github/workflows/deal-check.yml`

Le plus simple depuis iPhone:
- ouvre chaque fichier dans Notes ou Fichiers,
- copie-colle le contenu dans GitHub avec "Create new file".

### 5) Ajouter les secrets GitHub
Dans ton repo:
Settings → Secrets and variables → Actions → New repository secret

Ajoute:
- `TELEGRAM_BOT_TOKEN` = le token de BotFather
- `TELEGRAM_CHAT_ID` = ton chat ID

### 6) Tester
Va dans:
Actions → Laptop Deals Canada → Run workflow

Tu devrais recevoir un message Telegram.

## Horaire
Le script tourne tous les jours à:
- 10:00 Montréal
- 15:00 Montréal

Pendant l'heure d'été, ça correspond à 14:00 et 19:00 UTC.
